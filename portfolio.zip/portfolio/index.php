<?php

session_start();

$conn = new mysqli('localhost', 'root', '', 'testing');

$errors = [];

$Success = [];

if(isset($_POST['signup-btn'])){
    
    if(empty($_POST['name'])){
      
       $errors['name'] = "Name is required";
       
    }
    
    if(empty($_POST['email'])){
      
       $errors['email'] = "email is required";
       
    }
    
    if(empty($_POST['phoneNo'])){
      
       $errors['phoneNo'] = "Phone Number is required";
       
    }
    
    $username = $_POST['name'];
   
    $email = $_POST['email'];
    
    $phoneNo = $_POST['phoneNo'];
    
    $leadscore = $_POST['leadScore'];
    
    $score = '';
    
    if($leadscore < 20){
        
        $score = rand(0 , 10);
    }
    
    if($leadscore < 40){
        
        $score = rand(20 , 40);
    }
    
    if($leadscore < 80){
        
        $score = rand(40 , 80);
    }
    
    if($leadscore < 120){
        
        $score = rand(80 , 100);
    }
    
    $sql = "SELECT * FROM `registereduser` WHERE email='$email' LIMIT 1";
  
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
    
        $errors['email'] = "Email already exists";

    }
    
    if (count($errors) === 0) {
        
        $query = "INSERT INTO `registereduser` SET username=?, email=?, phoneNo=?, LeadScore=?";
        
        $stmt = $conn->prepare($query);
        
        $stmt->bind_param('ssss', $username, $email, $phoneNo, $score);
        
        $result = $stmt->execute();
         
        require 'class/PHPMailerAutoload.php';

        $mail = new PHPMailer;

        //$mail->SMTPDebug = 4;                                           // Enable verbose debug output

        $mail->isSMTP();                                              // Set mailer to use SMTP

        $mail->Host = 'smtp.gmail.com';                              // Specify main and backup SMTP servers

        $mail->SMTPAuth = true;                                     // Enable SMTP authentication

        $mail->Username = 'webenginessolutions@gmail.com';                  // SMTP username

        $mail->Password = 'Ravindra@1096';                           // SMTP password

        $mail->SMTPSecure = 'tls';                               // Enable TLS encryption, `ssl` also accepted

        $mail->Port = 587;                                      // TCP port to connect to

        $mail->setFrom('webenginessolutions@gmail.com', 'Web Engines');

        $mail->addAddress($email, $username);                // Add a recipient

        $mail->addAddress('jsagar1846@gmail.com');          // Name is optional

        $mail->addReplyTo($email, $username);

        $mail->isHTML(true);                              // Set email format to HTML

        $mail->Subject = 'Registration Successfull';

        $mail->Body    = '
        <h2 style="text-align= center;">Hi Thank you for showing interest in the <b>WebEngines Webinars!</b></h2><br> 
        <p>Please check below details for the webinars<p><br>
        <table>
        <tr>
        <th>Date</th>
        <th>Time</th>
        <th>Cost</th>
        <th>Speaker</th>
        <th>Topic</th>
        </tr>
        <tr>
        <td>Fri, 12th Jun</td>
        <td>07:00 PM (IST)</th>
        <td>FREE</th>
        <td>Arun Jagannathan</th>
        <td>GMAT Verbal</th>
        </tr>
        </table>
        ';

        $mail->AltBody = '<h2 style="text-align= center;">Hi Thank you for showing interest in the <b>WebEngines Webinars!</b></h2><br> 
        <p>Please check below details for the webinars<p><br>
        <table>
        <tr>
        <th>Date</th>
        <th>Time</th>
        <th>Cost</th>
        <th>Speaker</th>
        <th>Topic</th>
        </tr>
        <tr>
        <td>Fri, 12th Jun</td>
        <td>07:00 PM (IST)</th>
        <td>FREE</th>
        <td>Iris Watson </th>
        <td>GMAT Verbal</th>
        </tr>
        </table>
        ';

        if(!$mail->send()) {

            $errors['email'] = "Mail Not Send";
       

            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }
    
        else {
    
        $Success['success'] = "Hi, You Successfully Registered to our portal Please Check Your Email Id For The Confirmation Mail";
    
        }

        
        
    }
    
}




?>

<!doctype html>
<html lang="en">
  
    <head>
    
        <!-- Required meta tags -->
            
        <meta charset="utf-8">
        
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

        <link rel="icon" href="res/search.png">
        
        <title>WebEngines: The Complete Web Solution</title>
        
        <link rel="stylesheet" href="css/style.css">
        
        <style>

        #li{
            padding: 10px;
            list-style-image: url(sad.png);
        }

        
        </style>

        
    </head>
    
    <body data-spy="scroll">
     
        <nav class="navbar navbar-dark  sticky-top navbar-expand-lg " style="background-color: #05396B;">
          
           <a class="navbar-brand" href="#"> 
               <img src="res/search%20(1).png" width="30" height="30" class="d-inline-block align-top" alt="" loading="lazy">
   
               WebEngines
  
            </a>
           
           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
           
               <span class="navbar-toggler-icon"></span>
               
           </button>
           
           <div class="collapse navbar-collapse" id="navbarNavAltMarkup" data-target="#navbar-example">
           
               <div class="navbar-nav">
               
                   <a class="nav-item nav-link active" href="#">Home<span class="sr-only">(current)</span></a>
                   
                   <a class="nav-item nav-link" href="#Register">Register</a>
                   
                   <a class="nav-item nav-link" href="#session_detail">About Session</a>
                   
                   <a class="nav-item nav-link" href="#card_detail">Testimonials</a>
                   
                   <a class="nav-item nav-link" href="#meetinfo">Speaker</a>
                   
               </div>
               
           </div>

        </nav>
        
        <div class="jumbotron jumbotron-fluid" id="Register" style="background-color: #389583;">
        
           <div class="container">
           
               <h1><b>How to Effectively Utilize the Latest GMAT Online Exam Updates.</b></h1>
           
               <p class="lead">The GMAC recently released a bunch of updates on taking the GMAT from home, re-opening of test centers, and use of the physical whiteboard. These updates could have led to some confusion on how to go about taking the test.</p>
               
               <hr class="my-4">
               
               <!-- form title -->
               
               <h3 class="text-center form-title">Register</h3> <!-- or Login -->

               <?php if (count($errors) > 0): ?>
               
               <div class="alert alert-danger">
               
                   <?php foreach ($errors as $error): ?>
                  
                   <li id="li">
                   
                       <?php echo $error; ?>
                
                   </li>
                   
                   <?php endforeach;?>
                
               </div>
               
               <?php endif;?>
               
               <?php if (count($Success) > 0): ?>
               
               <div class="alert alert-success">
               
                   <?php foreach ($Success as $Success): ?>
                  
                       <?php echo $Success; ?>
                
                   <?php endforeach;?>
                
               </div>
               
               <?php endif;?>
               
               <form method="post" id="register_form">
            
                   <div class="container" id="login" style="background-color: #8DE4AF;">
                   
                       <div class="row">

                           <div class="col-sm-3">

                               <input type="text" class="form-control" name="name" id="name" aria-describedby="emailHelp" placeholder="Harry Potter">

                           </div>

                           <div class="col-sm-3">

                               <input type="email" class="form-control" name="email" id="email" placeholder="xyz@abc.com">

                           </div>

                           <div class="col-sm-3">

                               <input type="text" class="form-control" name="phoneNo" placeholder="9819338115">
                               
                               <input type="hidden" class="form-control" id="score" name="leadScore">

                               <input type="hidden" class="form-control" id="leadSource" name="leadSource">

                               <input type="hidden" class="form-control" id="leadLocation" name="leadLocation">

                               <input type="hidden" class="form-control"  id="LeadMedium" name="LeadMedium">
                               
                               <input type="hidden" class="form-control"  id="LeadCampaign" name="LeadCampaign">

                           </div>

                           <div class="col-sm-3">

                               <button type="submit" name="signup-btn" id="submit"  class="btn btn-success">Save Your Spot</button>

                           </div>

                       </div>

                   </div>

               </form>
              
           </div>
         
        </div>
          
        <div id="detail" style="background-color: #8DE4AF;">
            
            <div class="container">
               
                <div class="row">

                    <div class="col-sm-4">

                        <svg width="2em" height="2em" viewBox="0 0 16 16" class="bi bi-calendar4-week" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

                            <path fill-rule="evenodd" d="M14 2H2a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1zM2 1a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2H2z"/>

                            <path fill-rule="evenodd" d="M14 2H2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1zM2 1a2 2 0 0 0-2 2v2h16V3a2 2 0 0 0-2-2H2z"/>

                            <path fill-rule="evenodd" d="M3.5 0a.5.5 0 0 1 .5.5V1a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 .5-.5zm9 0a.5.5 0 0 1 .5.5V1a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 .5-.5z"/>

                            <path d="M11 7.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-2 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z"/>

                        </svg>

                        <h3>Fri, 12th Jun</h3>


                    </div>

                    <div class="col-sm-4">

                        <svg width="2em" height="2em" viewBox="0 0 16 16" class="bi bi-clock" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm8-7A8 8 0 1 1 0 8a8 8 0 0 1 16 0z"/>

                            <path fill-rule="evenodd" d="M7.5 3a.5.5 0 0 1 .5.5v5.21l3.248 1.856a.5.5 0 0 1-.496.868l-3.5-2A.5.5 0 0 1 7 9V3.5a.5.5 0 0 1 .5-.5z"/>

                        </svg>


                        <h3>07:00 PM (IST)</h3>


                    </div>

                    <div class="col-sm-4">

                        <svg width="2em" height="2em" viewBox="0 0 16 16" class="bi bi-cash" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

                            <path fill-rule="evenodd" d="M15 4H1v8h14V4zM1 3a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H1z"/>

                            <path d="M13 4a2 2 0 0 0 2 2V4h-2zM3 4a2 2 0 0 1-2 2V4h2zm10 8a2 2 0 0 1 2-2v2h-2zM3 12a2 2 0 0 0-2-2v2h2zm7-4a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/>

                        </svg>

                        <h3>FREE</h3>


                    </div>

                </div>
                
            </div>
               
        </div>
        
        <div id="session_detail">
            
            <div class="container">
            
                <h1>During this Free Session, You’ll Learn</h1>
                
                <hr class="my-4">
                
                <div class="row">
                
                    <div class="col-sm-7">
                    
                        <ul>
                        
                            <li>The 3 major updates released by the GMAC and how to effectively utilize them to your advantage.</li>
                            
                            <li>The key factors to decide whether to use the physical whiteboard or the online GMAT whiteboard.</li>
                            
                            <li>The pros and cons of taking the GMAT from home vs the GMAT test centres.</li>
                            
                            <li>The extended appointment dates for the GMAT Online Exam.</li>
                            
                            <li>The next best steps for those who plan to take the GMAT now.</li>
                            
                        </ul>
                        
                    </div>
                    
                    <div class="col-sm-5">
                        
                        <div class="container">
                            
                            <img class="feature" src="res/unnamed.png">
                            
                        </div>
                    
                    </div>

                </div>
            
            </div>
        
        </div>
           
        <div id="card_detail"> 
            
            <div class="container">
           
            <h1 class="display-5"><b>Why Choose Us</b></h1>

            <p class="lead">Here's What Our Students are Saying</p>

            <hr class="my-4">
           
            <div class="row">
                
                <div class="col-md-4">
                
                     <div class="card">
        
                        <img src="res/IMG_20190615_211047.jpg" class="card-img-top" alt="...">

                        <div class="card-body">

                            <h5 class="card-title">Sagar Jha</h5>

                            <p class="card-text">"In just two weeks I saw a score improvement. I knew I was making progress as I had my basics in place."</p>

                        </div>

                    </div>

                </div>
                
                 <div class="col-md-4">
                
                     <div class="card">
        
                        <img src="res/image%20(1).jpg" class="card-img-top" alt="...">

                        <div class="card-body">

                            <h5 class="card-title">Keni Jorden</h5>

                            <p class="card-text">"Webengines instructors were always ready to help me, whenever I needed help. Very supportive team."</p>

                        </div>

                    </div>

                </div>
                
                 <div class="col-md-4">
                
                     <div class="card">
        
                        <img src="res/desk.jpg" class="card-img-top" alt="...">

                        <div class="card-body">

                            <h5 class="card-title">Akash Jha</h5>

                            <p class="card-text">"Webengines armed me with the right strategies and tools to confidently take the exam."</p>

                        </div>

                    </div>

                </div>
                
            </div>
             
        </div>
            
        </div>
        
        <div  id="meetinfo" style="background-color:#389583; color:white;">
            
            <div class="container">
            
                <h1 class="display-5 center"><b>Meet the Speaker</b></h1>

                <hr class="my-4">

                <div class="container">

                    <div class="row">

                        <div class="col-sm-6">

                            <img class="speaker" src="res/image.jpg">

                        </div>

                        <div class="col-sm-6" id="DetailOfSpeaker">

                             <h3>Iris Watson | GMAT Verbal Expert</h3>

                             <hr class="my-4">

                             <p>
                                 Iris is the founder and CEO of WebEngines & one of the best GMAT verbal faculty in the country. He has trained more than 10,000 students for the GMAT since 2004.
                             </p>

                             <p>
                                Students love his sessions because he has the unique ability to transform every GMAT class into an insightful learning experience.
                             </p>

                             <p>
                                 He has mentored thousands of students & helped them get into top B-schools such as INSEAD, Wharton, Harvard, Stanford, & ISB to name a few.
                             </p>

                        </div>

                    </div>

                </div>
                
            </div>
            
        </div>
        
        <footer>
            
            <div class="container">
            
                <h5>© 2020 WebEngines | All Rights Reserved</h5>
                
            </div>
        
        </footer>
        
        <!-- Optional JavaScript -->
        
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
        
    </body>
    
</html>