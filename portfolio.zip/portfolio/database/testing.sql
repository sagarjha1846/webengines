-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2020 at 07:28 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testing`
--

-- --------------------------------------------------------

--
-- Table structure for table `registereduser`
--

CREATE TABLE `registereduser` (
  `id` int(11) NOT NULL,
  `username` varchar(512) NOT NULL,
  `email` varchar(512) NOT NULL,
  `phoneNo` varchar(10) NOT NULL,
  `LeadScore` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registereduser`
--

INSERT INTO `registereduser` (`id`, `username`, `email`, `phoneNo`, `LeadScore`) VALUES
(11, 'Sagar Jha', 'jsagar1846@gmail.com', '8901234560', 48),
(12, 'sagar jha', 'sagar.jharavi@gmail.com', '8850338145', 52),
(13, 'sagar jha', '2015sagar.jha@ves.ac.in', '8097760515', 40),
(14, 'Kanchan', 'sagarjha.divazmedia@gmail.com', '9123456789', 0),
(15, 'Ravi', 'kanchan19jha@gmail.com', '8907765152', 87),
(16, 'Kanchan jha', 'kanchan.jha.5688@gmail.com', '9137887608', 7),
(17, 'Mathew', 'sagarjha.divazmedia@gmail.com', '8850338145', 52),
(18, 'Ram', 'abc@xyz.com', '8850338145', 97),
(19, 'Ram', 'abc@xyz.com', '8850338145', 19),
(20, 'cjjdjd', 'jsagar1846@gmail.com', '8850338145', 63),
(21, 'cjjdjd', 'sag@gmail.com', '9137887608', 96),
(22, 'Kanchanjje', '2015swagar.jha@ves.ac.in', '9123456789', 92),
(23, 'Sagar jha', 'sag1@gmail.com', '8901234560', 92),
(24, 'tejes', 'tejaschoudhari3@gmail.com', '8907765152', 80);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registereduser`
--
ALTER TABLE `registereduser`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registereduser`
--
ALTER TABLE `registereduser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
